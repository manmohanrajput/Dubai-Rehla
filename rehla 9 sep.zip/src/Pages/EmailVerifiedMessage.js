import React from 'react'

export const EmailVerifiedMessage = () => {
  return (
    <div>EmailVerifiedMessage</div>
  )
}
