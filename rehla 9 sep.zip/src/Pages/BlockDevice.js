import React from 'react'

export const BlockDevice = () => {
  return (
    <div>BlockDevice</div>
  )
}
