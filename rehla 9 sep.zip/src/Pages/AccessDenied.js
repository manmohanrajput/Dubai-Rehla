import React from 'react'

export const AccessDenied = () => {
  return (
    <div>AccessDenied</div>
  )
}
