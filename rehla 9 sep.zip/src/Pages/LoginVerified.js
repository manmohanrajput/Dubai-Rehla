import React from 'react'

const LoginVerified = () => {
  return (
    <div>LoginVerified</div>
  )
}

export default LoginVerified