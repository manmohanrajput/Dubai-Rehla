import React from 'react'

const ProfileSpinner = () => {
  return (
    <div className="prof-spinner"></div>
  )
}

export default ProfileSpinner