import React from 'react'

const CustomSpinner = () => {
  return (
    <div class="loading">Loading&#8230</div>
  )
}

export default CustomSpinner